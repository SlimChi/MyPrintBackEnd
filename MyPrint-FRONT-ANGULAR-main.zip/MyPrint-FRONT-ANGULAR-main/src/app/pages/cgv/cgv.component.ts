import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-cgv',
  templateUrl: './cgv.component.html',
  styleUrls: ['./cgv.component.css']
})
export class CgvComponent implements OnInit{
  ngOnInit(): void {
  }

}
