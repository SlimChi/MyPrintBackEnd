import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-success-paiment',
  templateUrl: './success-paiment.component.html',
  styleUrls: ['./success-paiment.component.css']
})
export class SuccessPaimentComponent implements OnInit{
  ngOnInit(): void {
  }

}
