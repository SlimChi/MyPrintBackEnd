/* tslint:disable */
/* eslint-disable */
export interface AccountResponse {
  result?: string;
}
