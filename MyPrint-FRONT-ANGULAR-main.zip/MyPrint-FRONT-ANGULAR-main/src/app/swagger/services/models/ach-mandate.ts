/* tslint:disable */
/* eslint-disable */
export interface AchMandate {
  acceptedAt?: string;
  text?: string;
}
