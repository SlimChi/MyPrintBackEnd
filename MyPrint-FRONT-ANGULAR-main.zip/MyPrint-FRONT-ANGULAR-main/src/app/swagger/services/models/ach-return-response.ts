/* tslint:disable */
/* eslint-disable */
export interface AchReturnResponse {
  createdAt?: string;
  reasonCode?: string;
}
