/* tslint:disable */
/* eslint-disable */
export interface AddOn {
  amount?: number;
  currentBillingCycle?: number;
  description?: string;
  id?: string;
  kind?: string;
  name?: string;
  numberOfBillingCycles?: number;
  planId?: string;
  quantity?: number;
}
