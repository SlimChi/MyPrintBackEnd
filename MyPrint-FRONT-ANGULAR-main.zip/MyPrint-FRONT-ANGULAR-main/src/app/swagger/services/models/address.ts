/* tslint:disable */
/* eslint-disable */
export interface Address {
  company?: string;
  countryCodeAlpha2?: string;
  countryCodeAlpha3?: string;
  countryCodeNumeric?: string;
  countryName?: string;
  createdAt?: string;
  customerId?: string;
  extendedAddress?: string;
  firstName?: string;
  id?: string;
  lastName?: string;
  locality?: string;
  phoneNumber?: string;
  postalCode?: string;
  recipientName?: string;
  region?: string;
  streetAddress?: string;
  updatedAt?: string;
}
