/* tslint:disable */
/* eslint-disable */
export interface AmexExpressCheckoutCard {
  bin?: string;
  cardMemberExpiryDate?: string;
  cardMemberNumber?: string;
  cardType?: string;
  createdAt?: string;
  customerId?: string;
  default?: boolean;
  expirationMonth?: string;
  expirationYear?: string;
  imageUrl?: string;
  sourceDescription?: string;
  token?: string;
  updatedAt?: string;
}
