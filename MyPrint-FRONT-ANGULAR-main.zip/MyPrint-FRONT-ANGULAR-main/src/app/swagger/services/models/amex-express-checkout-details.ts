/* tslint:disable */
/* eslint-disable */
export interface AmexExpressCheckoutDetails {
  bin?: string;
  cardMemberExpiryDate?: string;
  cardMemberNumber?: string;
  cardType?: string;
  expirationMonth?: string;
  expirationYear?: string;
  imageUrl?: string;
  sourceDescription?: string;
  token?: string;
}
