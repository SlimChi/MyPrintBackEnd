/* tslint:disable */
/* eslint-disable */
export interface ApplePayDetails {
  bin?: string;
  cardType?: string;
  cardholderName?: string;
  commercial?: string;
  countryOfIssuance?: string;
  debit?: string;
  durbinRegulated?: string;
  expirationMonth?: string;
  expirationYear?: string;
  globalId?: string;
  healthcare?: string;
  imageUrl?: string;
  issuingBank?: string;
  last4?: string;
  paymentInstrumentName?: string;
  payroll?: string;
  prepaid?: string;
  productId?: string;
  sourceDescription?: string;
  token?: string;
}
