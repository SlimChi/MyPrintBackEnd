/* tslint:disable */
/* eslint-disable */
export interface AuthenticationRequest {
  email?: string;
  password?: string;
}
