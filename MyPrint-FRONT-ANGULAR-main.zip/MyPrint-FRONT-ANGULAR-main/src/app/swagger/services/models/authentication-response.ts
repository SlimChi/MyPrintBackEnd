/* tslint:disable */
/* eslint-disable */
export interface AuthenticationResponse {
  token?: string;
}
