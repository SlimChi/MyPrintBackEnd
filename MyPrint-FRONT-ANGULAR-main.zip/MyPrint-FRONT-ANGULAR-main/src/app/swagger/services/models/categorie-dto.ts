/* tslint:disable */
/* eslint-disable */
export interface CategorieDto {
  idCategorie?: number;
  libelle?: string;
}
