/* tslint:disable */
/* eslint-disable */
export interface ClientTokenDto {
  token?: string;
}
