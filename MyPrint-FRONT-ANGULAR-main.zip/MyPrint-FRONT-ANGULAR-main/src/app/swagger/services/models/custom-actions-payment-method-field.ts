/* tslint:disable */
/* eslint-disable */
export interface CustomActionsPaymentMethodField {
  displayValue?: string;
  name?: string;
}
