/* tslint:disable */
/* eslint-disable */
export interface Descriptor {
  name?: string;
  phone?: string;
  url?: string;
}
