/* tslint:disable */
/* eslint-disable */
export interface DisbursementDetails {
  disbursementDate?: string;
  fundsHeld?: boolean;
  settlementAmount?: number;
  settlementCurrencyExchangeRate?: number;
  settlementCurrencyIsoCode?: string;
  success?: boolean;
  valid?: boolean;
}
