/* tslint:disable */
/* eslint-disable */
export interface DisputeEvidence {
  category?: string;
  comment?: string;
  createdAt?: string;
  id?: string;
  sentToProcessorAt?: string;
  sequenceNumber?: string;
  url?: string;
}
