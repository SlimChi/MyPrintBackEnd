/* tslint:disable */
/* eslint-disable */
export interface DisputePayPalMessage {
  message?: string;
  sender?: string;
  sentAt?: string;
}
