/* tslint:disable */
/* eslint-disable */
export interface DisputeTransaction {
  amount?: number;
  createdAt?: string;
  id?: string;
  installmentCount?: number;
  orderId?: string;
  paymentInstrumentSubtype?: string;
  purchaseOrderNumber?: string;
}
