/* tslint:disable */
/* eslint-disable */
export interface EmailMessage {
  email?: string;
  subject?: string;
  to?: string;
}
