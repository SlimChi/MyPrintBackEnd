/* tslint:disable */
/* eslint-disable */
export interface FacilitatedDetails {
  merchantId?: string;
  merchantName?: string;
  paymentMethodNonce?: string;
}
