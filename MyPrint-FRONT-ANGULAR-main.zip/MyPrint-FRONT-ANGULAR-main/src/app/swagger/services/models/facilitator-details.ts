/* tslint:disable */
/* eslint-disable */
export interface FacilitatorDetails {
  oauthApplicationClientId?: string;
  oauthApplicationName?: string;
  sourcePaymentMethodToken?: string;
}
