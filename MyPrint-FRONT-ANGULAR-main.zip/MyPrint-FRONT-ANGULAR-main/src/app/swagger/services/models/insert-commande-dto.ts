/* tslint:disable */
/* eslint-disable */
export interface InsertCommandeDto {
  idAdresse?: number;
  idUtilisateur?: number;
  prix?: number;
}
