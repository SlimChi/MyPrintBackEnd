/* tslint:disable */
/* eslint-disable */
export interface InsertIntervenirDto {
  idUtilisateur?: number;
  numeroCommande?: number;
  numeroLigneCommande?: number;
}
