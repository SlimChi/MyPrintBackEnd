/* tslint:disable */
/* eslint-disable */
export interface InsertLigneCommandeDto {
  couleur?: boolean;
  format?: string;
  idFichier?: number;
  nombreExemplaire?: number;
  nombreFeuille?: number;
  numeroCommande?: number;
  prixLigneCommande?: number;
  rectoVerso?: boolean;
}
