/* tslint:disable */
/* eslint-disable */
export interface InsertUtilisateurDto {
  email?: string;
  nom?: string;
  prenom?: string;
  telephone?: string;
}
