/* tslint:disable */
/* eslint-disable */
export interface LiabilityShift {
  conditions?: Array<string>;
  responsibleParty?: string;
}
