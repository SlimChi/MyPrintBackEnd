/* tslint:disable */
/* eslint-disable */
export interface LocalPaymentDetails {
  captureId?: string;
  customField?: string;
  debugId?: string;
  description?: string;
  fundingSource?: string;
  payerId?: string;
  paymentId?: string;
  refundFromTransactionFeeAmount?: string;
  refundFromTransactionFeeCurrencyIsoCode?: string;
  refundId?: string;
  transactionFeeAmount?: string;
  transactionFeeCurrencyIsoCode?: string;
}
