/* tslint:disable */
/* eslint-disable */
export interface NewPassword {
  email?: string;
  password?: string;
  tokenPassword?: string;
}
