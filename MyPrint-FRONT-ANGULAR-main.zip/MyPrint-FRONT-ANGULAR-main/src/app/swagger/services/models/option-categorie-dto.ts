/* tslint:disable */
/* eslint-disable */
import { TypeOptionDto } from './type-option-dto';
export interface OptionCategorieDto {
  idCategorie?: number;
  typeOptionDto?: TypeOptionDto;
}
