/* tslint:disable */
/* eslint-disable */
export interface OptionDto {
  idOption?: number;
  libelle?: string;
}
