/* tslint:disable */
/* eslint-disable */
import { TypeOptionDto } from './type-option-dto';
export interface OptionLigneCommandeDto {
  numeroCommande?: number;
  numeroLigneCommande?: number;
  typeOptionDto?: TypeOptionDto;
}
