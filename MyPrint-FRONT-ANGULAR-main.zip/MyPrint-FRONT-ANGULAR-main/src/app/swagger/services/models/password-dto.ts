/* tslint:disable */
/* eslint-disable */
export interface PasswordDto {
  password?: string;
}
