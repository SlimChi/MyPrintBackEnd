/* tslint:disable */
/* eslint-disable */
export interface PayPalAccount {
  billingAgreementId?: string;
  createdAt?: string;
  customerId?: string;
  default?: boolean;
  email?: string;
  imageUrl?: string;
  payerId?: string;
  revokedAt?: string;
  token?: string;
  updatedAt?: string;
}
