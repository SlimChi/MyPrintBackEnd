/* tslint:disable */
/* eslint-disable */
export interface PayPalHereDetails {
  authorizationId?: string;
  captureId?: string;
  invoiceId?: string;
  last4?: string;
  paymentId?: string;
  paymentType?: string;
  refundId?: string;
  transactionFeeAmount?: string;
  transactionFeeCurrencyIsoCode?: string;
  transactionInitiationDate?: string;
  transactionUpdatedDate?: string;
}
