/* tslint:disable */
/* eslint-disable */
export interface PaymentMethod {
  customerId?: string;
  default?: boolean;
  imageUrl?: string;
  token?: string;
}
