/* tslint:disable */
/* eslint-disable */
export interface PurchaseDto {
  amount?: number;
  nonce?: string;
}
