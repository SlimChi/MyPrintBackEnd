/* tslint:disable */
/* eslint-disable */
export interface ResetPassword {
  email?: string;
}
