/* tslint:disable */
/* eslint-disable */
export interface ResponseMessage {
  message?: string;
}
