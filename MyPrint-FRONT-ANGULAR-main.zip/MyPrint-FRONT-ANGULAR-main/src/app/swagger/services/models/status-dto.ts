/* tslint:disable */
/* eslint-disable */
export interface StatusDto {
  idStatus?: number;
  libelle?: string;
}
