/* tslint:disable */
/* eslint-disable */
export interface SubscriptionDetails {
  billingPeriodEndDate?: string;
  billingPeriodStartDate?: string;
}
