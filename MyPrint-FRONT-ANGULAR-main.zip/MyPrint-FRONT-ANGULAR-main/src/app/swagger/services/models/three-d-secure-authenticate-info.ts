/* tslint:disable */
/* eslint-disable */
export interface ThreeDSecureAuthenticateInfo {
  transStatus?: string;
  transStatusReason?: string;
}
