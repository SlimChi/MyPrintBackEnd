/* tslint:disable */
/* eslint-disable */
export interface ThreeDSecureLookupInfo {
  transStatus?: string;
  transStatusReason?: string;
}
