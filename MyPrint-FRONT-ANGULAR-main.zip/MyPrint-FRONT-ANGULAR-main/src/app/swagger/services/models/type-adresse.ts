/* tslint:disable */
/* eslint-disable */
export interface TypeAdresse {
  id?: number;
  libelle?: string;
}
