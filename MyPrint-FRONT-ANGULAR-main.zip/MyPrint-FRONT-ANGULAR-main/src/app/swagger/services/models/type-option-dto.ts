/* tslint:disable */
/* eslint-disable */
export interface TypeOptionDto {
  idOption?: number;
  idTypeOption?: number;
  libelle?: string;
  prix?: number;
}
