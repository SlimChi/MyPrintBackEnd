/* tslint:disable */
/* eslint-disable */
export interface VenmoAccountDetails {
  imageUrl?: string;
  sourceDescription?: string;
  token?: string;
  username?: string;
  venmoUserId?: string;
}
