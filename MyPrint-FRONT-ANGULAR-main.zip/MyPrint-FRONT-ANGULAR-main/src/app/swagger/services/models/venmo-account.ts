/* tslint:disable */
/* eslint-disable */
export interface VenmoAccount {
  createdAt?: string;
  customerId?: string;
  default?: boolean;
  imageUrl?: string;
  sourceDescription?: string;
  token?: string;
  updatedAt?: string;
  username?: string;
  venmoUserId?: string;
}
