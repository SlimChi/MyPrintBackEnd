package fr.rt.MyPrintRed.controllers;

public class BaseUrl {

    private static String URL = "http://localhost:8080/";
    final static String FRONT_BASE_URL ="http://localhost:4200";
    final static String UTILISATEUR_BASE_URL = URL+"adresseutilisateur";
    final static String ADRESSE_BASE_URL = URL+"adresses";
    final static String ADRESSE_UTILISATEUR_BASE_URL =URL+"adresseutilisateur";

    final static String COMMANDE_BASE_URL =URL+"commandes";

    final static String LIGNE_COMMANDE_BASE_URL = URL+"lignecommandes";

    final static String STATUS_BASE_URL = URL + "statuses";

    final static String OPTION_BASE_URL = URL +"options";

    final static String OPTION_CATEGORIE_BASE_URL = URL +"optioncategories";

    final static String OPTION_LIGNE_COMMANDE_BASE_URL = URL + "optionlignecommandes";

    final static String TYPE_OPTION_BASE_URL = URL + "typeoptions";

    final static String INTERVENIR_BASE_URL = URL + "intervenirs";

    final static String FICHIER_BASE_URL = URL + "fichiers";
}
