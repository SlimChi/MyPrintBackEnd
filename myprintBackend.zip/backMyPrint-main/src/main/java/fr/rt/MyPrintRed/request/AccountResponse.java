package fr.rt.MyPrintRed.request;

import lombok.Data;

/**
 * @author slim
 * @Project
 */
@Data
public class AccountResponse {
    private String  result;
}
