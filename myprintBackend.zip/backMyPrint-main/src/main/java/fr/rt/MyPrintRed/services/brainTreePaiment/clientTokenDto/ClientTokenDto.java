package fr.rt.MyPrintRed.services.brainTreePaiment.clientTokenDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author slimane
 * @Project
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ClientTokenDto {

    private  String token;
}
